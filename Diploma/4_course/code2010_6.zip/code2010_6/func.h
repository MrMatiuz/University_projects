void inp_mesh(void);
void inp_gdf(void);
void deriv_lr(void);
void deriv_du(void);
void step(void);
double  flow_lr(void);
double  flow_du(void);
void new_gdf(void);

void out(void);
void out_tec(void);
void memo_on(void);

void riemi(double *par,int *alarm);
